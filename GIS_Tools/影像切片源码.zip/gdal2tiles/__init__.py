# -*- coding: utf-8 -*-

"""Top-level package for gdal2tiles library."""

__author__ = """Tehamalab"""
__email__ = 'developers@tehamalab.com'
__version__ = '0.1.9'


from .gdal2tiles import *  # noqa
